import Firebase
import FirebaseFirestore

class FirebaseManager {
    static let shared = FirebaseManager()
    let db = Firestore.firestore()

    func syncColors(_ colors: [ColorData], completion: @escaping () -> Void) {
        let batch = db.batch()
        for color in colors {
            let docRef = db.collection("colors").document()
            batch.setData([
                "hex": color.hex,
                "timestamp": color.timestamp
            ], forDocument: docRef)
        }
        batch.commit { error in
            if error == nil {
                completion()
            }
        }
    }
}
