import Foundation

class LocalStorageManager {
    static let shared = LocalStorageManager()
    let key = "SavedColors"

    func save(_ color: ColorData) {
        var colors = load()
        colors.append(color)
        if let data = try? JSONEncoder().encode(colors) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    func load() -> [ColorData] {
        if let data = UserDefaults.standard.data(forKey: key),
           let colors = try? JSONDecoder().decode([ColorData].self, from: data) {
            return colors
        }
        return []
    }

    func clear() {
        UserDefaults.standard.removeObject(forKey: key)
    }
}
