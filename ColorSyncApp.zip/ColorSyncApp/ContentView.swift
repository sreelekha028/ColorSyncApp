import SwiftUI

struct ContentView: View {
    @State private var colors: [ColorData] = LocalStorageManager.shared.load()
    @StateObject var networkMonitor = NetworkMonitor()

    var body: some View {
        VStack {
            Text(networkMonitor.isConnected ? "🟢 Online" : "🔴 Offline")
                .padding()

            Button("Generate Color") {
                let hex = String(format: "#%06X", Int.random(in: 0...0xFFFFFF))
                let color = ColorData(hex: hex, timestamp: Date())
                colors.append(color)
                LocalStorageManager.shared.save(color)

                if networkMonitor.isConnected {
                    FirebaseManager.shared.syncColors([color]) {
                        print("Synced to Firebase!")
                    }
                }
            }
            .padding()
            .background(Color.blue)
            .foregroundColor(.white)
            .cornerRadius(8)

            ScrollView {
                ForEach(colors) { color in
                    ColorCardView(hex: color.hex)
                }
            }
        }
        .onAppear {
            colors = LocalStorageManager.shared.load()
        }
    }
}
