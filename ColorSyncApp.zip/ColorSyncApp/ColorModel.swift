import Foundation

struct ColorData: Identifiable, Codable {
    let id = UUID()
    let hex: String
    let timestamp: Date
}
